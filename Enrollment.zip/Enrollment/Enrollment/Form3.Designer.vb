﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Add_Rec_Click = New Button()
        Clear_Click = New Button()
        Delete_Click = New Button()
        SearchBox_Click = New Button()
        Update_Click = New Button()
        Search_Box = New TextBox()
        St_Track = New TextBox()
        St_Strand = New TextBox()
        St_MI = New TextBox()
        St_FName = New TextBox()
        St_LName = New TextBox()
        Label6 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        Label9 = New Label()
        Label10 = New Label()
        Label11 = New Label()
        Label12 = New Label()
        Label13 = New Label()
        St_LRN = New TextBox()
        St_GradeLevel = New TextBox()
        St_Section = New TextBox()
        St_Semester = New TextBox()
        St_SchoolYear = New TextBox()
        Button1 = New Button()
        SuspendLayout()
        ' 
        ' Add_Rec_Click
        ' 
        Add_Rec_Click.BackColor = SystemColors.Highlight
        Add_Rec_Click.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Add_Rec_Click.ForeColor = SystemColors.ButtonHighlight
        Add_Rec_Click.Location = New Point(576, 719)
        Add_Rec_Click.Name = "Add_Rec_Click"
        Add_Rec_Click.Size = New Size(212, 74)
        Add_Rec_Click.TabIndex = 32
        Add_Rec_Click.Text = "Add Record"
        Add_Rec_Click.UseVisualStyleBackColor = False
        ' 
        ' Clear_Click
        ' 
        Clear_Click.BackColor = SystemColors.Highlight
        Clear_Click.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Clear_Click.ForeColor = SystemColors.ButtonHighlight
        Clear_Click.Location = New Point(1015, 321)
        Clear_Click.Name = "Clear_Click"
        Clear_Click.Size = New Size(212, 74)
        Clear_Click.TabIndex = 31
        Clear_Click.Text = "Clear"
        Clear_Click.UseVisualStyleBackColor = False
        ' 
        ' Delete_Click
        ' 
        Delete_Click.BackColor = SystemColors.Highlight
        Delete_Click.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Delete_Click.ForeColor = SystemColors.ButtonHighlight
        Delete_Click.Location = New Point(1135, 634)
        Delete_Click.Name = "Delete_Click"
        Delete_Click.Size = New Size(212, 74)
        Delete_Click.TabIndex = 30
        Delete_Click.Text = "Delete"
        Delete_Click.UseVisualStyleBackColor = False
        ' 
        ' SearchBox_Click
        ' 
        SearchBox_Click.BackColor = SystemColors.Highlight
        SearchBox_Click.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        SearchBox_Click.ForeColor = SystemColors.ButtonHighlight
        SearchBox_Click.Location = New Point(1015, 216)
        SearchBox_Click.Name = "SearchBox_Click"
        SearchBox_Click.Size = New Size(212, 74)
        SearchBox_Click.TabIndex = 29
        SearchBox_Click.Text = "Search"
        SearchBox_Click.UseVisualStyleBackColor = False
        ' 
        ' Update_Click
        ' 
        Update_Click.BackColor = SystemColors.Highlight
        Update_Click.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Update_Click.ForeColor = SystemColors.ButtonHighlight
        Update_Click.Location = New Point(1135, 536)
        Update_Click.Name = "Update_Click"
        Update_Click.Size = New Size(212, 74)
        Update_Click.TabIndex = 28
        Update_Click.Text = "Update"
        Update_Click.UseVisualStyleBackColor = False
        ' 
        ' Search_Box
        ' 
        Search_Box.BackColor = Color.Cornsilk
        Search_Box.Font = New Font("Cambria", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        Search_Box.ForeColor = SystemColors.HotTrack
        Search_Box.Location = New Point(984, 147)
        Search_Box.Name = "Search_Box"
        Search_Box.Size = New Size(256, 31)
        Search_Box.TabIndex = 27
        ' 
        ' St_Track
        ' 
        St_Track.BackColor = Color.Cornsilk
        St_Track.Font = New Font("Cambria", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        St_Track.ForeColor = SystemColors.HotTrack
        St_Track.Location = New Point(559, 419)
        St_Track.Name = "St_Track"
        St_Track.Size = New Size(256, 31)
        St_Track.TabIndex = 26
        ' 
        ' St_Strand
        ' 
        St_Strand.BackColor = Color.Cornsilk
        St_Strand.Font = New Font("Cambria", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        St_Strand.ForeColor = SystemColors.HotTrack
        St_Strand.Location = New Point(559, 364)
        St_Strand.Name = "St_Strand"
        St_Strand.Size = New Size(256, 31)
        St_Strand.TabIndex = 25
        ' 
        ' St_MI
        ' 
        St_MI.BackColor = Color.Cornsilk
        St_MI.Font = New Font("Cambria", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        St_MI.ForeColor = SystemColors.HotTrack
        St_MI.Location = New Point(559, 311)
        St_MI.Name = "St_MI"
        St_MI.Size = New Size(256, 31)
        St_MI.TabIndex = 24
        ' 
        ' St_FName
        ' 
        St_FName.BackColor = Color.Cornsilk
        St_FName.Font = New Font("Cambria", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        St_FName.ForeColor = SystemColors.HotTrack
        St_FName.Location = New Point(559, 259)
        St_FName.Name = "St_FName"
        St_FName.Size = New Size(256, 31)
        St_FName.TabIndex = 23
        ' 
        ' St_LName
        ' 
        St_LName.BackColor = Color.Cornsilk
        St_LName.Font = New Font("Cambria", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        St_LName.ForeColor = SystemColors.HotTrack
        St_LName.Location = New Point(559, 209)
        St_LName.Name = "St_LName"
        St_LName.Size = New Size(256, 31)
        St_LName.TabIndex = 22
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label6.ForeColor = SystemColors.MenuHighlight
        Label6.Location = New Point(138, 364)
        Label6.Name = "Label6"
        Label6.Size = New Size(0, 36)
        Label6.TabIndex = 21
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label5.ForeColor = SystemColors.MenuHighlight
        Label5.Location = New Point(138, 313)
        Label5.Name = "Label5"
        Label5.Size = New Size(197, 36)
        Label5.TabIndex = 20
        Label5.Text = "Middle Initial"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label4.ForeColor = SystemColors.MenuHighlight
        Label4.Location = New Point(138, 259)
        Label4.Name = "Label4"
        Label4.Size = New Size(163, 36)
        Label4.TabIndex = 19
        Label4.Text = "First Name"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.MenuHighlight
        Label3.Location = New Point(138, 200)
        Label3.Name = "Label3"
        Label3.Size = New Size(157, 36)
        Label3.TabIndex = 17
        Label3.Text = "Last Name"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label2.ForeColor = SystemColors.MenuHighlight
        Label2.Location = New Point(138, 147)
        Label2.Name = "Label2"
        Label2.Size = New Size(395, 36)
        Label2.TabIndex = 18
        Label2.Text = "Learners Reference Number"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Cambria", 22.2F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label1.ForeColor = SystemColors.Highlight
        Label1.Location = New Point(559, 32)
        Label1.Name = "Label1"
        Label1.Size = New Size(243, 43)
        Label1.TabIndex = 16
        Label1.Text = "Student Form"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label7.ForeColor = SystemColors.MenuHighlight
        Label7.Location = New Point(138, 313)
        Label7.Name = "Label7"
        Label7.Size = New Size(197, 36)
        Label7.TabIndex = 20
        Label7.Text = "Middle Initial"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label8.ForeColor = SystemColors.MenuHighlight
        Label8.Location = New Point(138, 369)
        Label8.Name = "Label8"
        Label8.Size = New Size(114, 36)
        Label8.TabIndex = 33
        Label8.Text = "Strand "
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label9.ForeColor = SystemColors.MenuHighlight
        Label9.Location = New Point(138, 431)
        Label9.Name = "Label9"
        Label9.Size = New Size(93, 36)
        Label9.TabIndex = 34
        Label9.Text = "Track"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label10.ForeColor = SystemColors.MenuHighlight
        Label10.Location = New Point(138, 489)
        Label10.Name = "Label10"
        Label10.Size = New Size(174, 36)
        Label10.TabIndex = 35
        Label10.Text = "Grade Level"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label11.ForeColor = SystemColors.MenuHighlight
        Label11.Location = New Point(138, 545)
        Label11.Name = "Label11"
        Label11.Size = New Size(113, 36)
        Label11.TabIndex = 35
        Label11.Text = "Section"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label12.ForeColor = SystemColors.MenuHighlight
        Label12.Location = New Point(139, 604)
        Label12.Name = "Label12"
        Label12.Size = New Size(169, 36)
        Label12.TabIndex = 36
        Label12.Text = "School Year"
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label13.ForeColor = SystemColors.MenuHighlight
        Label13.Location = New Point(143, 664)
        Label13.Name = "Label13"
        Label13.Size = New Size(139, 36)
        Label13.TabIndex = 36
        Label13.Text = "Semester"
        ' 
        ' St_LRN
        ' 
        St_LRN.BackColor = Color.Cornsilk
        St_LRN.Font = New Font("Cambria", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        St_LRN.ForeColor = SystemColors.HotTrack
        St_LRN.Location = New Point(559, 156)
        St_LRN.Name = "St_LRN"
        St_LRN.Size = New Size(256, 31)
        St_LRN.TabIndex = 37
        ' 
        ' St_GradeLevel
        ' 
        St_GradeLevel.BackColor = Color.Cornsilk
        St_GradeLevel.Font = New Font("Cambria", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        St_GradeLevel.ForeColor = SystemColors.HotTrack
        St_GradeLevel.Location = New Point(559, 479)
        St_GradeLevel.Name = "St_GradeLevel"
        St_GradeLevel.Size = New Size(256, 31)
        St_GradeLevel.TabIndex = 38
        ' 
        ' St_Section
        ' 
        St_Section.BackColor = Color.Cornsilk
        St_Section.Font = New Font("Cambria", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        St_Section.ForeColor = SystemColors.HotTrack
        St_Section.Location = New Point(559, 545)
        St_Section.Name = "St_Section"
        St_Section.Size = New Size(256, 31)
        St_Section.TabIndex = 39
        ' 
        ' St_Semester
        ' 
        St_Semester.BackColor = Color.Cornsilk
        St_Semester.Font = New Font("Cambria", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        St_Semester.ForeColor = SystemColors.HotTrack
        St_Semester.Location = New Point(559, 664)
        St_Semester.Name = "St_Semester"
        St_Semester.Size = New Size(256, 31)
        St_Semester.TabIndex = 39
        ' 
        ' St_SchoolYear
        ' 
        St_SchoolYear.BackColor = Color.Cornsilk
        St_SchoolYear.Font = New Font("Cambria", 12.0F, FontStyle.Bold, GraphicsUnit.Point)
        St_SchoolYear.ForeColor = SystemColors.HotTrack
        St_SchoolYear.Location = New Point(559, 604)
        St_SchoolYear.Name = "St_SchoolYear"
        St_SchoolYear.Size = New Size(256, 31)
        St_SchoolYear.TabIndex = 39
        ' 
        ' Button1
        ' 
        Button1.BackColor = SystemColors.Highlight
        Button1.Font = New Font("Cambria", 18.0F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Button1.ForeColor = SystemColors.ButtonHighlight
        Button1.Location = New Point(509, 896)
        Button1.Name = "Button1"
        Button1.Size = New Size(293, 74)
        Button1.TabIndex = 40
        Button1.Text = "Back to Main Menu"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Form3
        ' 
        AutoScaleDimensions = New SizeF(8.0F, 20.0F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1405, 999)
        Controls.Add(Button1)
        Controls.Add(St_SchoolYear)
        Controls.Add(St_Semester)
        Controls.Add(St_Section)
        Controls.Add(St_GradeLevel)
        Controls.Add(St_LRN)
        Controls.Add(Label13)
        Controls.Add(Label12)
        Controls.Add(Label11)
        Controls.Add(Label10)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Add_Rec_Click)
        Controls.Add(Clear_Click)
        Controls.Add(Delete_Click)
        Controls.Add(SearchBox_Click)
        Controls.Add(Update_Click)
        Controls.Add(Search_Box)
        Controls.Add(St_Track)
        Controls.Add(St_Strand)
        Controls.Add(St_MI)
        Controls.Add(St_FName)
        Controls.Add(St_LName)
        Controls.Add(Label6)
        Controls.Add(Label7)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form3"
        Text = "Form3"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Add_Rec_Click As Button
    Friend WithEvents Clear_Click As Button
    Friend WithEvents Delete_Click As Button
    Friend WithEvents SearchBox_Click As Button
    Friend WithEvents Update_Click As Button
    Friend WithEvents Search_Box As TextBox
    Friend WithEvents St_Track As TextBox
    Friend WithEvents St_Strand As TextBox
    Friend WithEvents St_MI As TextBox
    Friend WithEvents St_FName As TextBox
    Friend WithEvents St_LName As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents St_LRN As TextBox
    Friend WithEvents St_GradeLevel As TextBox
    Friend WithEvents St_Section As TextBox
    Friend WithEvents St_Semester As TextBox
    Friend WithEvents St_SchoolYear As TextBox
    Friend WithEvents Button1 As Button
End Class
