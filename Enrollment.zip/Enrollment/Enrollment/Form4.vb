﻿Imports System.Data.SqlClient


Public Class Form4
    Dim conn As New SqlConnection("Data Source=DESKTOP-RD1U9LO\SQLEXPRESS; Initial Catalog=Enrollment System; Integrated Security = True")
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim cmd As New SqlCommand("SELECT * FROM Student", conn)
        Dim da As New SqlDataAdapter(cmd)
        Dim dt As New DataTable
        da.Fill(dt)

        S_LRN.DataSource = dt
        S_LRN.DisplayMember = "St_LRN"
        S_LRN.ValueMember = "St_LRN"
    End Sub

    Public Sub ExecuteQuery(ByVal query As String)
        Dim cmd As New SqlCommand(query, conn)
        conn.Open()
        cmd.ExecuteNonQuery()
        conn.Close()
    End Sub

    Private Sub Add_Rec_Click_Click(sender As Object, e As EventArgs) Handles Add_Rec_Click.Click
        If String.IsNullOrEmpty(T_Number.Text) Or String.IsNullOrEmpty(T_Type.Text) Then
            MessageBox.Show("Incomplete Details", "INCOMPLETE", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            Dim cmd As New SqlCommand("SELECT COUNT FROM Transaction", conn)
            Dim da As New SqlDataAdapter(cmd)
            Dim TNO As New Integer
            TNO = da

            Dim Insertquery As String = "INSERT INTO Transaction (T_Number, T_StudentLRN) values ('" & T_Number.Text & "', '" & T_Type.Text & "')"
            ExecuteQuery(Insertquery)
            MessageBox.Show("Record Added Successfully", "INSERT", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub T_Number_SelectedIndexChanged(sender As Object, e As EventArgs) Handles S_LRN.SelectedIndexChanged

    End Sub
End Class