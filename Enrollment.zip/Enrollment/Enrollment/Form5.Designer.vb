﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        P_ID = New TextBox()
        Label9 = New Label()
        Label8 = New Label()
        Add_Rec_Click = New Button()
        Clear_Click = New Button()
        Delete_Click = New Button()
        SearchBox_Click = New Button()
        Update_Click = New Button()
        Search_Box = New TextBox()
        P_Position = New TextBox()
        P_BDate = New TextBox()
        P_MI = New TextBox()
        P_FName = New TextBox()
        P_LName = New TextBox()
        Label6 = New Label()
        Label7 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        Button1 = New Button()
        SuspendLayout()
        ' 
        ' P_ID
        ' 
        P_ID.BackColor = Color.Cornsilk
        P_ID.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        P_ID.ForeColor = SystemColors.HotTrack
        P_ID.Location = New Point(494, 169)
        P_ID.Name = "P_ID"
        P_ID.Size = New Size(256, 31)
        P_ID.TabIndex = 64
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label9.ForeColor = SystemColors.MenuHighlight
        Label9.Location = New Point(73, 444)
        Label9.Name = "Label9"
        Label9.Size = New Size(125, 36)
        Label9.TabIndex = 59
        Label9.Text = "Position"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label8.ForeColor = SystemColors.MenuHighlight
        Label8.Location = New Point(73, 382)
        Label8.Name = "Label8"
        Label8.Size = New Size(145, 36)
        Label8.TabIndex = 58
        Label8.Text = "Birthdate"
        ' 
        ' Add_Rec_Click
        ' 
        Add_Rec_Click.BackColor = SystemColors.Highlight
        Add_Rec_Click.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Add_Rec_Click.ForeColor = SystemColors.ButtonHighlight
        Add_Rec_Click.Location = New Point(505, 530)
        Add_Rec_Click.Name = "Add_Rec_Click"
        Add_Rec_Click.Size = New Size(212, 74)
        Add_Rec_Click.TabIndex = 57
        Add_Rec_Click.Text = "Add Record"
        Add_Rec_Click.UseVisualStyleBackColor = False
        ' 
        ' Clear_Click
        ' 
        Clear_Click.BackColor = SystemColors.Highlight
        Clear_Click.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Clear_Click.ForeColor = SystemColors.ButtonHighlight
        Clear_Click.Location = New Point(919, 336)
        Clear_Click.Name = "Clear_Click"
        Clear_Click.Size = New Size(212, 74)
        Clear_Click.TabIndex = 56
        Clear_Click.Text = "Clear"
        Clear_Click.UseVisualStyleBackColor = False
        ' 
        ' Delete_Click
        ' 
        Delete_Click.BackColor = SystemColors.Highlight
        Delete_Click.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Delete_Click.ForeColor = SystemColors.ButtonHighlight
        Delete_Click.Location = New Point(1013, 628)
        Delete_Click.Name = "Delete_Click"
        Delete_Click.Size = New Size(212, 74)
        Delete_Click.TabIndex = 55
        Delete_Click.Text = "Delete"
        Delete_Click.UseVisualStyleBackColor = False
        ' 
        ' SearchBox_Click
        ' 
        SearchBox_Click.BackColor = SystemColors.Highlight
        SearchBox_Click.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        SearchBox_Click.ForeColor = SystemColors.ButtonHighlight
        SearchBox_Click.Location = New Point(919, 229)
        SearchBox_Click.Name = "SearchBox_Click"
        SearchBox_Click.Size = New Size(212, 74)
        SearchBox_Click.TabIndex = 54
        SearchBox_Click.Text = "Search"
        SearchBox_Click.UseVisualStyleBackColor = False
        ' 
        ' Update_Click
        ' 
        Update_Click.BackColor = SystemColors.Highlight
        Update_Click.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Update_Click.ForeColor = SystemColors.ButtonHighlight
        Update_Click.Location = New Point(1013, 530)
        Update_Click.Name = "Update_Click"
        Update_Click.Size = New Size(212, 74)
        Update_Click.TabIndex = 53
        Update_Click.Text = "Update"
        Update_Click.UseVisualStyleBackColor = False
        ' 
        ' Search_Box
        ' 
        Search_Box.BackColor = Color.Cornsilk
        Search_Box.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Search_Box.ForeColor = SystemColors.HotTrack
        Search_Box.Location = New Point(899, 169)
        Search_Box.Name = "Search_Box"
        Search_Box.Size = New Size(256, 31)
        Search_Box.TabIndex = 52
        ' 
        ' P_Position
        ' 
        P_Position.BackColor = Color.Cornsilk
        P_Position.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        P_Position.ForeColor = SystemColors.HotTrack
        P_Position.Location = New Point(494, 432)
        P_Position.Name = "P_Position"
        P_Position.Size = New Size(256, 31)
        P_Position.TabIndex = 51
        ' 
        ' P_BDate
        ' 
        P_BDate.BackColor = Color.Cornsilk
        P_BDate.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        P_BDate.ForeColor = SystemColors.HotTrack
        P_BDate.Location = New Point(494, 377)
        P_BDate.Name = "P_BDate"
        P_BDate.Size = New Size(256, 31)
        P_BDate.TabIndex = 50
        ' 
        ' P_MI
        ' 
        P_MI.BackColor = Color.Cornsilk
        P_MI.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        P_MI.ForeColor = SystemColors.HotTrack
        P_MI.Location = New Point(494, 324)
        P_MI.Name = "P_MI"
        P_MI.Size = New Size(256, 31)
        P_MI.TabIndex = 49
        ' 
        ' P_FName
        ' 
        P_FName.BackColor = Color.Cornsilk
        P_FName.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        P_FName.ForeColor = SystemColors.HotTrack
        P_FName.Location = New Point(494, 272)
        P_FName.Name = "P_FName"
        P_FName.Size = New Size(256, 31)
        P_FName.TabIndex = 48
        ' 
        ' P_LName
        ' 
        P_LName.BackColor = Color.Cornsilk
        P_LName.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        P_LName.ForeColor = SystemColors.HotTrack
        P_LName.Location = New Point(494, 222)
        P_LName.Name = "P_LName"
        P_LName.Size = New Size(256, 31)
        P_LName.TabIndex = 47
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label6.ForeColor = SystemColors.MenuHighlight
        Label6.Location = New Point(73, 377)
        Label6.Name = "Label6"
        Label6.Size = New Size(0, 36)
        Label6.TabIndex = 46
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label7.ForeColor = SystemColors.MenuHighlight
        Label7.Location = New Point(73, 326)
        Label7.Name = "Label7"
        Label7.Size = New Size(197, 36)
        Label7.TabIndex = 45
        Label7.Text = "Middle Initial"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label5.ForeColor = SystemColors.MenuHighlight
        Label5.Location = New Point(73, 326)
        Label5.Name = "Label5"
        Label5.Size = New Size(197, 36)
        Label5.TabIndex = 44
        Label5.Text = "Middle Initial"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label4.ForeColor = SystemColors.MenuHighlight
        Label4.Location = New Point(73, 272)
        Label4.Name = "Label4"
        Label4.Size = New Size(163, 36)
        Label4.TabIndex = 43
        Label4.Text = "First Name"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.MenuHighlight
        Label3.Location = New Point(73, 213)
        Label3.Name = "Label3"
        Label3.Size = New Size(157, 36)
        Label3.TabIndex = 41
        Label3.Text = "Last Name"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label2.ForeColor = SystemColors.MenuHighlight
        Label2.Location = New Point(73, 160)
        Label2.Name = "Label2"
        Label2.Size = New Size(305, 36)
        Label2.TabIndex = 42
        Label2.Text = "Personnel ID Number"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Cambria", 22.2F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label1.ForeColor = SystemColors.Highlight
        Label1.Location = New Point(494, 45)
        Label1.Name = "Label1"
        Label1.Size = New Size(280, 43)
        Label1.TabIndex = 40
        Label1.Text = "Personnel Form"
        ' 
        ' Button1
        ' 
        Button1.BackColor = SystemColors.Highlight
        Button1.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Button1.ForeColor = SystemColors.ButtonHighlight
        Button1.Location = New Point(457, 662)
        Button1.Name = "Button1"
        Button1.Size = New Size(302, 92)
        Button1.TabIndex = 65
        Button1.Text = "Back to Main Menu"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Form5
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1267, 782)
        Controls.Add(Button1)
        Controls.Add(P_ID)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Add_Rec_Click)
        Controls.Add(Clear_Click)
        Controls.Add(Delete_Click)
        Controls.Add(SearchBox_Click)
        Controls.Add(Update_Click)
        Controls.Add(Search_Box)
        Controls.Add(P_Position)
        Controls.Add(P_BDate)
        Controls.Add(P_MI)
        Controls.Add(P_FName)
        Controls.Add(P_LName)
        Controls.Add(Label6)
        Controls.Add(Label7)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form5"
        Text = "Form5"
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents P_ID As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Add_Rec_Click As Button
    Friend WithEvents Clear_Click As Button
    Friend WithEvents Delete_Click As Button
    Friend WithEvents SearchBox_Click As Button
    Friend WithEvents Update_Click As Button
    Friend WithEvents Search_Box As TextBox
    Friend WithEvents P_Position As TextBox
    Friend WithEvents P_BDate As TextBox
    Friend WithEvents P_MI As TextBox
    Friend WithEvents P_FName As TextBox
    Friend WithEvents P_LName As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
End Class
