﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Button1 = New Button()
        Add_Rec_Click = New Button()
        S_LRN = New ComboBox()
        T_Type = New ComboBox()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Cambria", 22.2F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label1.ForeColor = SystemColors.Highlight
        Label1.Location = New Point(594, 65)
        Label1.Name = "Label1"
        Label1.Size = New Size(220, 43)
        Label1.TabIndex = 41
        Label1.Text = "Transaction"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label2.ForeColor = SystemColors.MenuHighlight
        Label2.Location = New Point(85, 186)
        Label2.Name = "Label2"
        Label2.Size = New Size(395, 36)
        Label2.TabIndex = 42
        Label2.Text = "Learners Reference Number"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.MenuHighlight
        Label3.Location = New Point(85, 278)
        Label3.Name = "Label3"
        Label3.Size = New Size(80, 36)
        Label3.TabIndex = 43
        Label3.Text = "Type"
        ' 
        ' Button1
        ' 
        Button1.BackColor = SystemColors.Highlight
        Button1.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Button1.ForeColor = SystemColors.ButtonHighlight
        Button1.Location = New Point(571, 600)
        Button1.Name = "Button1"
        Button1.Size = New Size(293, 74)
        Button1.TabIndex = 44
        Button1.Text = "Back to Main Menu"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Add_Rec_Click
        ' 
        Add_Rec_Click.BackColor = SystemColors.Highlight
        Add_Rec_Click.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Add_Rec_Click.ForeColor = SystemColors.ButtonHighlight
        Add_Rec_Click.Location = New Point(602, 391)
        Add_Rec_Click.Name = "Add_Rec_Click"
        Add_Rec_Click.Size = New Size(212, 74)
        Add_Rec_Click.TabIndex = 83
        Add_Rec_Click.Text = "Submit"
        Add_Rec_Click.UseVisualStyleBackColor = False
        ' 
        ' S_LRN
        ' 
        S_LRN.BackColor = Color.Cornsilk
        S_LRN.Font = New Font("Cambria", 22.2F, FontStyle.Bold, GraphicsUnit.Point)
        S_LRN.ForeColor = SystemColors.HotTrack
        S_LRN.FormattingEnabled = True
        S_LRN.Location = New Point(571, 186)
        S_LRN.Name = "S_LRN"
        S_LRN.Size = New Size(300, 51)
        S_LRN.TabIndex = 84
        ' 
        ' T_Type
        ' 
        T_Type.BackColor = Color.Cornsilk
        T_Type.Font = New Font("Cambria", 22.2F, FontStyle.Bold, GraphicsUnit.Point)
        T_Type.ForeColor = SystemColors.HotTrack
        T_Type.FormattingEnabled = True
        T_Type.Items.AddRange(New Object() {"School", "Subject"})
        T_Type.Location = New Point(571, 278)
        T_Type.Name = "T_Type"
        T_Type.Size = New Size(300, 51)
        T_Type.TabIndex = 85
        ' 
        ' Form4
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1343, 686)
        Controls.Add(T_Type)
        Controls.Add(S_LRN)
        Controls.Add(Add_Rec_Click)
        Controls.Add(Button1)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form4"
        Text = "Form4"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Add_Rec_Click As Button
    Friend WithEvents S_LRN As ComboBox
    Friend WithEvents T_Type As ComboBox
End Class
