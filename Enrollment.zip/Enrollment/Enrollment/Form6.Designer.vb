﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Sc_ID = New TextBox()
        Label9 = New Label()
        Label8 = New Label()
        Add_Rec_Click = New Button()
        Clear_Click = New Button()
        Delete_Click = New Button()
        SearchBox_Click = New Button()
        Update_Click = New Button()
        Search_Box = New TextBox()
        Sc_GradeLevel = New TextBox()
        Sc_Track = New TextBox()
        Sc_Strand = New TextBox()
        Sc_SchoolYear = New TextBox()
        Sc_Name = New TextBox()
        Label6 = New Label()
        Label7 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        Sc_Semester = New TextBox()
        Label10 = New Label()
        Sc_Section = New TextBox()
        Button1 = New Button()
        SuspendLayout()
        ' 
        ' Sc_ID
        ' 
        Sc_ID.BackColor = Color.Cornsilk
        Sc_ID.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Sc_ID.ForeColor = SystemColors.HotTrack
        Sc_ID.Location = New Point(597, 194)
        Sc_ID.Name = "Sc_ID"
        Sc_ID.Size = New Size(256, 31)
        Sc_ID.TabIndex = 85
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label9.ForeColor = SystemColors.MenuHighlight
        Label9.Location = New Point(176, 469)
        Label9.Name = "Label9"
        Label9.Size = New Size(174, 36)
        Label9.TabIndex = 84
        Label9.Text = "Grade Level"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label8.ForeColor = SystemColors.MenuHighlight
        Label8.Location = New Point(176, 407)
        Label8.Name = "Label8"
        Label8.Size = New Size(93, 36)
        Label8.TabIndex = 83
        Label8.Text = "Track"
        ' 
        ' Add_Rec_Click
        ' 
        Add_Rec_Click.BackColor = SystemColors.Highlight
        Add_Rec_Click.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Add_Rec_Click.ForeColor = SystemColors.ButtonHighlight
        Add_Rec_Click.Location = New Point(619, 663)
        Add_Rec_Click.Name = "Add_Rec_Click"
        Add_Rec_Click.Size = New Size(212, 74)
        Add_Rec_Click.TabIndex = 82
        Add_Rec_Click.Text = "Add Record"
        Add_Rec_Click.UseVisualStyleBackColor = False
        ' 
        ' Clear_Click
        ' 
        Clear_Click.BackColor = SystemColors.Highlight
        Clear_Click.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Clear_Click.ForeColor = SystemColors.ButtonHighlight
        Clear_Click.Location = New Point(1064, 349)
        Clear_Click.Name = "Clear_Click"
        Clear_Click.Size = New Size(212, 74)
        Clear_Click.TabIndex = 81
        Clear_Click.Text = "Clear"
        Clear_Click.UseVisualStyleBackColor = False
        ' 
        ' Delete_Click
        ' 
        Delete_Click.BackColor = SystemColors.Highlight
        Delete_Click.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Delete_Click.ForeColor = SystemColors.ButtonHighlight
        Delete_Click.Location = New Point(1154, 647)
        Delete_Click.Name = "Delete_Click"
        Delete_Click.Size = New Size(212, 74)
        Delete_Click.TabIndex = 80
        Delete_Click.Text = "Delete"
        Delete_Click.UseVisualStyleBackColor = False
        ' 
        ' SearchBox_Click
        ' 
        SearchBox_Click.BackColor = SystemColors.Highlight
        SearchBox_Click.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        SearchBox_Click.ForeColor = SystemColors.ButtonHighlight
        SearchBox_Click.Location = New Point(1064, 254)
        SearchBox_Click.Name = "SearchBox_Click"
        SearchBox_Click.Size = New Size(212, 74)
        SearchBox_Click.TabIndex = 79
        SearchBox_Click.Text = "Search"
        SearchBox_Click.UseVisualStyleBackColor = False
        ' 
        ' Update_Click
        ' 
        Update_Click.BackColor = SystemColors.Highlight
        Update_Click.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Update_Click.ForeColor = SystemColors.ButtonHighlight
        Update_Click.Location = New Point(1154, 549)
        Update_Click.Name = "Update_Click"
        Update_Click.Size = New Size(212, 74)
        Update_Click.TabIndex = 78
        Update_Click.Text = "Update"
        Update_Click.UseVisualStyleBackColor = False
        ' 
        ' Search_Box
        ' 
        Search_Box.BackColor = Color.Cornsilk
        Search_Box.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Search_Box.ForeColor = SystemColors.HotTrack
        Search_Box.Location = New Point(998, 190)
        Search_Box.Name = "Search_Box"
        Search_Box.Size = New Size(317, 31)
        Search_Box.TabIndex = 77
        ' 
        ' Sc_GradeLevel
        ' 
        Sc_GradeLevel.BackColor = Color.Cornsilk
        Sc_GradeLevel.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Sc_GradeLevel.ForeColor = SystemColors.HotTrack
        Sc_GradeLevel.Location = New Point(597, 457)
        Sc_GradeLevel.Name = "Sc_GradeLevel"
        Sc_GradeLevel.Size = New Size(256, 31)
        Sc_GradeLevel.TabIndex = 76
        ' 
        ' Sc_Track
        ' 
        Sc_Track.BackColor = Color.Cornsilk
        Sc_Track.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Sc_Track.ForeColor = SystemColors.HotTrack
        Sc_Track.Location = New Point(597, 402)
        Sc_Track.Name = "Sc_Track"
        Sc_Track.Size = New Size(256, 31)
        Sc_Track.TabIndex = 75
        ' 
        ' Sc_Strand
        ' 
        Sc_Strand.BackColor = Color.Cornsilk
        Sc_Strand.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Sc_Strand.ForeColor = SystemColors.HotTrack
        Sc_Strand.Location = New Point(597, 349)
        Sc_Strand.Name = "Sc_Strand"
        Sc_Strand.Size = New Size(256, 31)
        Sc_Strand.TabIndex = 74
        ' 
        ' Sc_SchoolYear
        ' 
        Sc_SchoolYear.BackColor = Color.Cornsilk
        Sc_SchoolYear.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Sc_SchoolYear.ForeColor = SystemColors.HotTrack
        Sc_SchoolYear.Location = New Point(597, 297)
        Sc_SchoolYear.Name = "Sc_SchoolYear"
        Sc_SchoolYear.Size = New Size(256, 31)
        Sc_SchoolYear.TabIndex = 73
        ' 
        ' Sc_Name
        ' 
        Sc_Name.BackColor = Color.Cornsilk
        Sc_Name.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Sc_Name.ForeColor = SystemColors.HotTrack
        Sc_Name.Location = New Point(597, 247)
        Sc_Name.Name = "Sc_Name"
        Sc_Name.Size = New Size(256, 31)
        Sc_Name.TabIndex = 72
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label6.ForeColor = SystemColors.MenuHighlight
        Label6.Location = New Point(176, 402)
        Label6.Name = "Label6"
        Label6.Size = New Size(0, 36)
        Label6.TabIndex = 71
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label7.ForeColor = SystemColors.MenuHighlight
        Label7.Location = New Point(176, 527)
        Label7.Name = "Label7"
        Label7.Size = New Size(113, 36)
        Label7.TabIndex = 70
        Label7.Text = "Section"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label5.ForeColor = SystemColors.MenuHighlight
        Label5.Location = New Point(176, 349)
        Label5.Name = "Label5"
        Label5.Size = New Size(107, 36)
        Label5.TabIndex = 69
        Label5.Text = "Strand"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label4.ForeColor = SystemColors.MenuHighlight
        Label4.Location = New Point(176, 297)
        Label4.Name = "Label4"
        Label4.Size = New Size(169, 36)
        Label4.TabIndex = 68
        Label4.Text = "School Year"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.MenuHighlight
        Label3.Location = New Point(176, 238)
        Label3.Name = "Label3"
        Label3.Size = New Size(187, 36)
        Label3.TabIndex = 66
        Label3.Text = "School Name"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label2.ForeColor = SystemColors.MenuHighlight
        Label2.Location = New Point(176, 185)
        Label2.Name = "Label2"
        Label2.Size = New Size(256, 36)
        Label2.TabIndex = 67
        Label2.Text = "School ID Number"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Cambria", 22.2F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label1.ForeColor = SystemColors.Highlight
        Label1.Location = New Point(597, 70)
        Label1.Name = "Label1"
        Label1.Size = New Size(223, 43)
        Label1.TabIndex = 65
        Label1.Text = "School Form"
        ' 
        ' Sc_Semester
        ' 
        Sc_Semester.BackColor = Color.Cornsilk
        Sc_Semester.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Sc_Semester.ForeColor = SystemColors.HotTrack
        Sc_Semester.Location = New Point(597, 577)
        Sc_Semester.Name = "Sc_Semester"
        Sc_Semester.Size = New Size(256, 31)
        Sc_Semester.TabIndex = 86
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label10.ForeColor = SystemColors.MenuHighlight
        Label10.Location = New Point(176, 587)
        Label10.Name = "Label10"
        Label10.Size = New Size(139, 36)
        Label10.TabIndex = 87
        Label10.Text = "Semester"
        ' 
        ' Sc_Section
        ' 
        Sc_Section.BackColor = Color.Cornsilk
        Sc_Section.Font = New Font("Cambria", 12F, FontStyle.Bold, GraphicsUnit.Point)
        Sc_Section.ForeColor = SystemColors.HotTrack
        Sc_Section.Location = New Point(597, 518)
        Sc_Section.Name = "Sc_Section"
        Sc_Section.Size = New Size(256, 31)
        Sc_Section.TabIndex = 88
        ' 
        ' Button1
        ' 
        Button1.BackColor = SystemColors.Highlight
        Button1.Font = New Font("Cambria", 18F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Button1.ForeColor = SystemColors.ButtonHighlight
        Button1.Location = New Point(580, 796)
        Button1.Name = "Button1"
        Button1.Size = New Size(293, 74)
        Button1.TabIndex = 89
        Button1.Text = "Back to Main Menu"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Form6
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1475, 890)
        Controls.Add(Button1)
        Controls.Add(Sc_Section)
        Controls.Add(Label10)
        Controls.Add(Sc_Semester)
        Controls.Add(Sc_ID)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Add_Rec_Click)
        Controls.Add(Clear_Click)
        Controls.Add(Delete_Click)
        Controls.Add(SearchBox_Click)
        Controls.Add(Update_Click)
        Controls.Add(Search_Box)
        Controls.Add(Sc_GradeLevel)
        Controls.Add(Sc_Track)
        Controls.Add(Sc_Strand)
        Controls.Add(Sc_SchoolYear)
        Controls.Add(Sc_Name)
        Controls.Add(Label6)
        Controls.Add(Label7)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form6"
        Text = "Form6"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Sc_ID As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Add_Rec_Click As Button
    Friend WithEvents Clear_Click As Button
    Friend WithEvents Delete_Click As Button
    Friend WithEvents SearchBox_Click As Button
    Friend WithEvents Update_Click As Button
    Friend WithEvents Search_Box As TextBox
    Friend WithEvents Sc_GradeLevel As TextBox
    Friend WithEvents Sc_Track As TextBox
    Friend WithEvents Sc_Strand As TextBox
    Friend WithEvents Sc_SchoolYear As TextBox
    Friend WithEvents Sc_Name As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Sc_Semester As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Sc_Section As TextBox
    Friend WithEvents Button1 As Button
End Class
